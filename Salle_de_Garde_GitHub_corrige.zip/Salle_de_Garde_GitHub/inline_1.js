
// === CONFIG FIREBASE - Ton projet Salledegarde ===
import { initializeApp } from "firebase/app";
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, signOut } from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyB1xKlA3C5nL1Fs_1bOs12qA1_Wz3_lWXw",
  authDomain: "salledegarde-89dae.firebaseapp.com",
  projectId: "salledegarde-89dae",
  storageBucket: "salledegarde-89dae.firebasestorage.app",
  messagingSenderId: "565366383143",
  appId: "1:565366383143:web:fb205e7996e202c72b2402",
  measurementId: "G-D3C3XQ66E4"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const googleProvider = new GoogleAuthProvider();

window._fbAuth = auth; window._fbDb = db;
console.log("Firebase connecté:", firebaseConfig.projectId);

// === Sync vers Firestore (infini, gratuit, rules if true) ===
window._fbSync = async function(k,v){
  try{
    const user = auth.currentUser;
    if(!user) return;
    if(k === "sdg_auto_hist_v1") {
      // Sauvegarde progression illimitée
      await setDoc(doc(db, "progression", user.uid), { hist: v, email: user.email, updatedAt: serverTimestamp() }, { merge: true });
    }
    if(k === "sdg_auto_state_v1") {
      await setDoc(doc(db, "etats", user.uid), { etat: v, updatedAt: serverTimestamp() }, { merge: true });
    }
  }catch(e){ console.log("Sync Firestore", e); }
};

let isGuest = false; // Mode invité désactivé - connexion obligatoire
localStorage.removeItem("sdg_guest_mode");


function showApp(user){
  document.getElementById("auth-root").style.display="none";
  document.getElementById("main-ui").style.display="block";
  const info = document.getElementById("user-info");
  if(user) {
    info.innerHTML = `<b>${user.email}</b> • Progression sauvegardée en illimité`;
  } else {
    info.innerHTML = `<b>Mode invité</b> • Sauvegarde locale seulement`;
  }
  // Crée bouton profil dans le header
  try{
    const bar = document.querySelector("#main-ui .bar");
    if(bar && !document.getElementById("btn-profile-open")){
      const right = document.createElement("div");
      right.style.display="flex"; right.style.alignItems="center"; right.style.gap="8px";
      const initial = user ? (user.email[0] || 'D').toUpperCase() : 'I';
      right.innerHTML = `<button id="btn-profile-open" class="btn-profile" title="Bulletin de profil">${initial}</button>`;
      bar.appendChild(right);
      document.getElementById("btn-profile-open").onclick = ()=> window._openProfile();
    }
    // Met à jour initiale si déjà là
    const btn = document.getElementById("btn-profile-open");
    if(btn && user) btn.textContent = (user.email[0]||'D').toUpperCase();
  }catch(e){ console.log(e); }
  
  // Expose fonctions profil globalement
  window._openProfile = async function(){
    const overlay = document.getElementById("profile-overlay");
    overlay.classList.add("open");
    // Remplit avec données auth + Firestore + hist
    try{
      const user = window._fbAuth ? window._fbAuth.currentUser : null;
      const hist = (window._fbGetHist ? window._fbGetHist() : []) || [];
      const n = hist.length;
      const avg = n ? Math.round(hist.reduce((s,x)=>s+(x.total||0),0)/n) : 0;
      const last = n ? hist[n-1].total : '--';
      document.getElementById("kpi-cases").textContent = n;
      document.getElementById("kpi-moy").textContent = n ? avg : '--';
      document.getElementById("kpi-last").textContent = last;
      
      // === BADGES DYNAMIQUES par temps + score ===
      // Badge temps : basé sur nombre de cas + ancienneté
      let badgeTempsText = '⏱️ Nouveau';
      let badgeTempsColor = 'var(--surface-2)';
      if(n===0){
        badgeTempsText = '⏱️ Nouveau • 0 cas';
      }else{
        // calcule ancienneté depuis premier cas
        const first = hist[0]?.t ? new Date(hist[0].t) : new Date();
        const days = Math.floor((Date.now() - first.getTime())/(1000*60*60*24));
        const totalMinutes = n * 12; // estimation 12min par cas
        const hours = Math.floor(totalMinutes/60);
        const mins = totalMinutes%60;
        const tempsStr = hours>0 ? `${hours}h ${mins}min` : `${mins}min`;
        
        if(n < 3){
          badgeTempsText = `🌱 Débutant • ${tempsStr}`;
        }else if(n < 10){
          badgeTempsText = `🔵 Régulier • ${tempsStr} • ${days}j`;
        }else if(n < 25){
          badgeTempsText = `🟣 Assidu • ${tempsStr} • ${days}j`;
        }else{
          badgeTempsText = `🟠 Vétéran • ${tempsStr} • ${days}j`;
        }
      }
      const elTemps = document.getElementById("badge-temps");
      if(elTemps) elTemps.textContent = badgeTempsText;
      
      // Badge score : basé sur moyenne + dernier score
      let badgeScoreText = '🎯 En formation';
      if(n===0){
        badgeScoreText = '🎯 À commencer';
      }else if(avg < 50){
        badgeScoreText = `📚 En formation • ${avg}/100`;
      }else if(avg < 65){
        badgeScoreText = `✅ Compétent • ${avg}/100`;
      }else if(avg < 80){
        badgeScoreText = `⭐ Avancé • ${avg}/100`;
      }else{
        badgeScoreText = `🏆 Expert • ${avg}/100`;
      }
      // bonus si progression
      if(n>=2){
        const prev = hist[n-2]?.total || 0;
        const curr = hist[n-1]?.total || 0;
        const diff = curr - prev;
        if(diff > 5) badgeScoreText += ' • 📈 en hausse';
        else if(diff < -5) badgeScoreText += ' • 📉 à revoir';
      }
      const elScore = document.getElementById("badge-score");
      if(elScore) elScore.textContent = badgeScoreText;
      
      if(user){
        document.getElementById("profile-email").textContent = user.email;
        document.getElementById("info-email").textContent = user.email;
        document.getElementById("info-uid").textContent = user.uid;
        document.getElementById("profile-nom").textContent = user.displayName || user.email.split('@')[0];
        document.getElementById("info-nom").textContent = user.displayName || '--';
        // Avatar
        const av = document.getElementById("profile-avatar");
        const overlayTextEl = document.getElementById("avatar-overlay-text");
        if(user.photoURL){
          // Photo existante
          av.innerHTML = `<img src="${user.photoURL}" alt="avatar" style="width:100%;height:100%;object-fit:cover;"><div class="avatar-overlay"><span style="font-size:18px;">📷</span><span id="avatar-overlay-text">Changer</span></div>`;
          av.classList.add("has-photo");
        }else{
          av.innerHTML = `${(user.email[0]||'D').toUpperCase()}<div class="avatar-overlay"><span style="font-size:18px;">📷</span><span id="avatar-overlay-text">Ajouter</span></div>`;
          av.classList.remove("has-photo");
        }
        // Essaie de charger infos medecin depuis Firestore
        try{
          const { doc, getDoc } = await import("firebase/firestore");
          const { getFirestore } = await import("firebase/firestore");
          const db = getFirestore();
          const snap = await getDoc(doc(db, "medecins", user.uid));
          if(snap.exists()){
            // Si photoURL dans Firestore et pas déjà dans auth
            if(d.photoURL && !user.photoURL){
              const av2 = document.getElementById("profile-avatar");
              av2.innerHTML = `<img src="${d.photoURL}" alt="avatar" style="width:100%;height:100%;object-fit:cover;"><div class="avatar-overlay"><span style="font-size:18px;">📷</span><span>Changer</span></div>`;
              av2.classList.add("has-photo");
              const btnP = document.getElementById("btn-profile-open");
              if(btnP) btnP.innerHTML = `<img src="${d.photoURL}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
            }
            const d = snap.data();
            if(d.nom){ document.getElementById("profile-nom").textContent = d.nom; document.getElementById("info-nom").textContent = d.nom; }
            if(d.hopital){ document.getElementById("info-hop").textContent = d.hopital; }
            else if(d.hop){ document.getElementById("info-hop").textContent = d.hop; }
          }
        }catch(e){ console.log("medecin fetch", e); }
      }
    }catch(e){ console.log(e); }
  };
  window._closeProfile = function(){
    document.getElementById("profile-overlay").classList.remove("open");
  };
}

window._closeProfile = function(){ document.getElementById("profile-overlay")?.classList.remove("open"); };


function showAuth(){
  document.getElementById("auth-root").style.display="flex";
  document.getElementById("main-ui").style.display="none";
}

// Tabs
document.getElementById("tab-login").onclick = ()=>{
  document.getElementById("form-login").style.display="block";
  document.getElementById("form-register").style.display="none";
  document.getElementById("tab-login").classList.add("btn"); document.getElementById("tab-login").classList.remove("ghost");
  document.getElementById("tab-register").classList.remove("btn"); document.getElementById("tab-register").classList.add("ghost");
};
document.getElementById("tab-register").onclick = ()=>{
  document.getElementById("form-login").style.display="none";
  document.getElementById("form-register").style.display="block";
  document.getElementById("tab-register").classList.add("btn"); document.getElementById("tab-register").classList.remove("ghost");
  document.getElementById("tab-login").classList.remove("btn"); document.getElementById("tab-login").classList.add("ghost");
};
document.getElementById("tab-login").click();

// Login
document.getElementById("btn-login").onclick = async ()=>{
  const email = document.getElementById("login-email").value.trim();
  const pass = document.getElementById("login-pass").value;
  const errEl = document.getElementById("login-error");
  errEl.textContent="";
  try{
    await signInWithEmailAndPassword(auth, email, pass);
  }catch(e){ errEl.textContent = e.message; }
};
// Register
document.getElementById("btn-register").onclick = async ()=>{
  const nom = document.getElementById("reg-nom").value.trim();
  const hop = document.getElementById("reg-hop").value.trim();
  const email = document.getElementById("reg-email").value.trim();
  const pass = document.getElementById("reg-pass").value;
  const errEl = document.getElementById("reg-error");
  errEl.textContent="";
  try{
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    // Enregistre dans Firestore collection medecins (infini)
    await setDoc(doc(db, "medecins", cred.user.uid), {
      nom: nom, hopital: hop, email: email, createdAt: serverTimestamp(), projectId: "salledegarde-89dae"
    });
  }catch(e){ errEl.textContent = e.message; }
};
// Google
document.getElementById("btn-google").onclick = async ()=>{
  try{ 
    const cred = await signInWithPopup(auth, googleProvider);
    await setDoc(doc(db, "medecins", cred.user.uid), {
      nom: cred.user.displayName || "", email: cred.user.email, photo: cred.user.photoURL || "", createdAt: serverTimestamp(), provider: "google"
    }, {merge:true});
  }catch(e){ document.getElementById("login-error").textContent = e.message; }
};
// Mode invité désactivé : connexion obligatoire pour voir évolutions
// document.getElementById("btn-guest") supprimé
// Logout
document.getElementById("btn-logout").onclick = async ()=>{
  localStorage.removeItem("sdg_guest_mode");
  await signOut(auth);
  showAuth();
};

// Auth state
onAuthStateChanged(auth, async (user)=>{
  if(user){
    localStorage.removeItem("sdg_guest_mode");
    // Charger progression depuis Firestore (infini)
    try{
      const snap = await getDoc(doc(db, "progression", user.uid));
      if(snap.exists() && snap.data().hist) {
        localStorage.setItem("sdg_auto_hist_v1", JSON.stringify(snap.data().hist));
        if(window._fbReloadHist) window._fbReloadHist();
      }
    }catch(e){ console.log(e); }
    showApp(user);
  } else {
    // Déconnexion totale : oblige à se connecter, pas d'accès invité
    localStorage.removeItem("sdg_guest_mode");
    showAuth();
  }
});

window._handleLogoutBulletin = async function(){
  try{
    // Déconnexion totale
    localStorage.removeItem("sdg_guest_mode");
    // Optionnel : on garde l'historique local pour le retrouver à la reconnexion, mais on bloque l'accès
    // Si tu veux tout effacer aussi, décommente la ligne suivante :
    // localStorage.removeItem("sdg_auto_hist_v1");
    // localStorage.removeItem("sdg_auto_state_v1");
    const { getAuth, signOut } = await import("firebase/auth");
    const auth = getAuth();
    await signOut(auth);
    // Force écran de connexion avant de voir évolutions
    document.getElementById("main-ui").style.display="none";
    document.getElementById("profile-overlay")?.classList.remove("open");
    document.getElementById("auth-root").style.display="flex";
    // Recharge pour être sûr que plus rien n'est visible sans connexion
    setTimeout(()=> location.reload(), 300);
  }catch(e){
    location.reload();
  }
};
document.getElementById("btn-logout-bulletin")?.addEventListener("click", window._handleLogoutBulletin);

// === GESTION PHOTO DE PROFIL - VERSION 100% GRATUITE SANS STORAGE (FIRESTORE SEULEMENT) ===
window._handleAvatarUpload = async function(event){
  const file = event.target.files?.[0];
  if(!file) return;
  
  // Validation - réduit à 1MB pour Firestore (base64)
  if(!file.type.startsWith('image/')){
    alert('Veuillez choisir une image');
    return;
  }
  if(file.size > 1.5*1024*1024){
    alert('Image trop grande pour le mode gratuit (max 1.5MB). Choisis une plus petite ou recadre-la.');
    return;
  }
  
  const avatarEl = document.getElementById('profile-avatar');
  
  try{
    // Affiche chargement
    const loading = document.createElement('div');
    loading.className = 'photo-uploading';
    loading.textContent = '⏳ Compression...';
    avatarEl.appendChild(loading);
    
    // Compresse l'image à 200x200 pour Firestore (économise de la place)
    const photoURL = await new Promise((resolve, reject)=>{
      const img = new Image();
      const reader = new FileReader();
      reader.onload = (e)=>{
        img.onload = ()=>{
          const canvas = document.createElement('canvas');
          const size = 200;
          canvas.width = size;
          canvas.height = size;
          const ctx = canvas.getContext('2d');
          // Crop carré au centre
          const min = Math.min(img.width, img.height);
          const sx = (img.width - min)/2;
          const sy = (img.height - min)/2;
          ctx.drawImage(img, sx, sy, min, min, 0, 0, size, size);
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
    
    loading.textContent = '⏳ Sauvegarde...';
    
    // Preview immédiat
    avatarEl.innerHTML = `<img src="${photoURL}" alt="avatar" style="width:100%;height:100%;object-fit:cover;"><div class="avatar-overlay"><span style="font-size:18px;">📷</span><span>Changer</span></div><div class="photo-uploading">⏳ Sauvegarde...</div>`;
    avatarEl.classList.add('has-photo');
    
    // Sauvegarde dans Firestore collection medecins (100% gratuit, pas besoin de Storage)
    const { getFirestore, doc, setDoc } = await import("firebase/firestore");
    const { getAuth } = await import("firebase/auth");
    const db = getFirestore();
    const auth = getAuth();
    const user = auth.currentUser;
    if(user){
      await setDoc(doc(db, "medecins", user.uid), { photoURL: photoURL, photoUpdatedAt: new Date().toISOString() }, { merge:true });
      // Met à jour bouton header
      const btnProfile = document.getElementById("btn-profile-open");
      if(btnProfile){
        btnProfile.innerHTML = `<img src="${photoURL}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
      }
      // Met à jour aussi user-info bar
      const info = document.getElementById("user-info");
      if(info) info.innerHTML = `<b>${user.email}</b> • Photo ajoutée ✅`;
    }
    
    // Nettoie
    setTimeout(()=>{
      avatarEl.querySelectorAll('.photo-uploading').forEach(el=>el.remove());
    }, 500);
    
  }catch(e){
    console.error(e);
    alert('Erreur: ' + e.message);
    avatarEl.querySelectorAll('.photo-uploading').forEach(el=>el.remove());
  }
  event.target.value = '';
};

// Attache l'event au file input
document.getElementById('avatar-file-input')?.addEventListener('change', window._handleAvatarUpload);

document.getElementById('avatar-file-input')?.addEventListener('change', window._handleAvatarUpload);


// === PROTECTION : bloque l'accès aux évolutions sans connexion ===
(function(){
  const origRender = window._fbReloadHist;
  // Surveille si l'utilisateur essaie d'accéder à progression sans être connecté
  setInterval(()=>{
    try{
      const user = window._fbAuth?.currentUser;
      const authRoot = document.getElementById("auth-root");
      const mainUi = document.getElementById("main-ui");
      if(!user && mainUi && mainUi.style.display!=="none" && authRoot && authRoot.style.display==="none"){
        // Pas connecté mais app visible -> force retour login
        mainUi.style.display="none";
        authRoot.style.display="flex";
      }
    }catch(e){}
  }, 500);
})();

