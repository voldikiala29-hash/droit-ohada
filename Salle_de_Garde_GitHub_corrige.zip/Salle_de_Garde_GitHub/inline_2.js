
// === CODE ORIGINAL DE TON APP (avec patch Firebase) ===

(function(){
"use strict";

/* =====================================================================
   OUTILS
   ===================================================================== */
function N(s){
  var t=String(s||"").toLowerCase().replace(/œ/g,"oe").replace(/æ/g,"ae").normalize("NFD")
    .replace(/[̀-ͯ]/g,"").replace(/[’‘`]/g,"'");
  // Tolérance fautes fréquentes Kinshasa
  t=t.replace(/pleinte/g,"plainte").replace(/plinte/g,"plainte").replace(/plaintes/g,"plainte")
     .replace(/atcd/g,"antecedent").replace(/atcds/g,"antecedent").replace(/atcdts/g,"antecedent")
     .replace(/fievres/g,"fievre").replace(/fievre/g,"fievre").replace(/pourqoi/g,"pourquoi").replace(/prkoi/g,"pourquoi")
     .replace(/motif/g,"motif").replace(/moti/g,"motif").replace(/pipi/g,"pipi").replace(/miction/g,"pipi");
  // Map mots isolés
  var map={pleinte:"plainte",plinte:"plainte",atcd:"antecedent",pourqoi:"pourquoi",prkoi:"pourquoi",dhr:"depuis quand",fievre:"fievre",pipi:"pipi"};
  t=t.split(/\s+/).map(function(w){return map[w]||w;}).join(" ");
  return t;
}
function rnd(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function pick(a){return a[Math.floor(Math.random()*a.length)];}
function uniq(a){return a.filter(function(x,i){return a.indexOf(x)===i;});}

var SERVICES=["Au hasard","Médecine interne","Pédiatrie","Gynéco-obstétrique","Chirurgie et urgences"];
var ORIS=["Traitement ambulatoire","Hospitalisation","Soins intensifs / réanimation","Référence vers un niveau supérieur","Bloc opératoire / chirurgie"];
var STEPS=["Anamnèse","Examen clinique","Paraclinique","Conclusion"];
var AXES=[["interrogatoire","Interrogatoire"],["examen_clinique","Examen clinique"],["examens_complementaires","Examens complémentaires"],["diagnostic","Diagnostic"],["traitement","Traitement"]];
var CHAT_CHIPS=["Depuis quand ?","Où avez-vous mal ?","Avez-vous de la fièvre ?","Avez-vous vomi ?","Quels sont vos antécédents ?","Quels médicaments avez-vous pris ?","Avez-vous des allergies ?"];
var EXAM_CHIPS=["constantes","état général","hydratation","cœur","poumons","abdomen","neurologique","gynéco-obstétrical","ostéo-articulaire","ORL","ganglions"];
var KEY="sdg_auto_state_v1", HKEY="sdg_auto_hist_v1";

var NM=["Patrick","Christian","Jean-Claude","Joël","Dieudonné","Blaise","Héritier","Fiston"];
var NF=["Nadège","Grâce","Chantal","Merveille","Francine","Sarah","Rachel","Espérance"];
var KM=["Jonathan","Exaucé","Gloire","Samuel","Prince"];
var KF=["Divine","Précieuse","Bénédicte","Ruth","Jemima"];
var COMMUNES=["Kalamu","Lemba","Ngaliema","Masina","Kimbanseke","Limete","Bandalungwa","N'djili","Makala","Selembao","Matete","Lingwala"];

/* =====================================================================
   EXAMENS CLINIQUES (valeurs normales par défaut)
   ===================================================================== */
var EXORDER=["const","gen","hydra","cardio","pulm","abdo","neuro","gyn","ortho","orl","gang","uro"];
var EX={
 const:{l:"Constantes",re:/constante|tension|\bta\b|pouls|frequence|temperature|\bfc\b|\bfr\b|saturation|spo2|poids/,n:"T° 36,8 °C · TA 120/75 mmHg · FC 76/min · FR 16/min · SpO2 98 % AA."},
 gen:{l:"État général",re:/general|inspection|conjonctive|muqueuse|icter|oedeme|pale|peau|aspect|etat|nutrition|cyanose|facies|brulure|plaie|lesion|cutane|surface|lund|regle des 9|scb|eruption|rash|cordon|ombilic|nouveau.?ne|succion/,n:"État général conservé, conjonctives colorées, pas d'ictère, pas d'œdème."},
 hydra:{l:"Hydratation",re:/hydrat|pli cutane|yeux|soif/,n:"Muqueuses humides, pli cutané immédiat, pas de soif anormale."},
 cardio:{l:"Cœur",re:/coeur|cardi|souffle|jugulaire|auscultation|galop/,n:"Bruits du cœur réguliers, pas de souffle, pas de signe d'insuffisance cardiaque."},
 pulm:{l:"Poumons",re:/poumon|pulmon|respir|thorax|auscultation|crepitant|tirage|sibilant|\bdep\b|debit de pointe/,n:"Thorax symétrique, murmure vésiculaire bilatéral, pas de bruit surajouté."},
 abdo:{l:"Abdomen",re:/abdom|ventre|palpation|foie|\brate\b|hepat|splen|defense|mcburney|mc burney|fosse iliaque|hernie|toucher rectal|\btr\b|peristalt/,n:"Abdomen souple, indolore, pas de masse, foie et rate non palpables, bruits hydro-aériques normaux."},
 neuro:{l:"Neurologique",re:/neuro|glasgow|conscience|reflexe|\brot\b|raideur|nuque|meninge|motricite|sensibilite|pupille|babinski|orientation|fontanelle|tonus|\bgcs\b|kernig|brudzinski|moro/,n:"Conscient, orienté, Glasgow 15, pas de déficit moteur ni sensitif, pas de raideur de nuque."},
 gyn:{l:"Gynéco-obstétrical",re:/obstetric|gyneco|hauteur uterine|\bhu\b|bcf|foetal|toucher vaginal|\btv\b|speculum|uterus|globe|saignement|vulve|perineum|delivrance|\bcol\b|contraction|mouvements actifs|presentation|pelvien/,n:"Examen gynéco-obstétrical sans particularité."},
 ortho:{l:"Ostéo-articulaire",re:/membre|mollet|osteo|articul|rachis|\bdos\b|jambe|\bmain|pied|fracture|dactylite|\bos\b/,n:"Pas de déformation ni de douleur ostéo-articulaire, mobilité normale."},
 orl:{l:"ORL",re:/\borl\b|gorge|pharyn|amygdal|oreille|\bnez\b|bouche|dent|tympan|koplik/,n:"Gorge, oreilles et nez sans particularité."},
 gang:{l:"Ganglions",re:/ganglion|adenopath/,n:"Pas d'adénopathie palpable."},
 uro:{l:"Génito-urinaire",re:/testicul|bourse|scrot|genital|genito|urinaire|prostate|globe vesical|vesical|meat|verge|penis|cremaster|prehn/,n:"Organes génitaux externes normaux, pas de globe vésical, loges rénales libres."}
};

/* =====================================================================
   EXAMENS COMPLÉMENTAIRES (résultats normaux par défaut)
   ===================================================================== */
var TORDER=["tdr","ge","nfs","hb","glyc","crp","creat","uree","iono","foie","ecg","rx","rxos","asp","echoabdo","echogyn","echocoeur","tdm","hemoc","widal","selles","ecbu","bu","grp","vih","genex","electro","tropo","lipase","coag","bhcg","ponction","gaz","fogd","pascite","alb","hbs","aslo","dopptest","echouro","psa"];
var TESTS={
 tdr:{l:"TDR paludisme",re:/\btdr\b|test rapide|diagnostic rapide/,n:"TDR paludisme : négatif."},
 ge:{l:"Goutte épaisse",re:/goutte|frottis|\bge\b|parasitemie|paludisme|plasmodium/,n:"Goutte épaisse : pas de Plasmodium vu."},
 nfs:{l:"NFS",re:/\bnfs\b|numeration|formule sanguine|hemogramme|globules|\bgb\b|plaquette/,n:"NFS : GB 7,2 G/L, Hb 13,0 g/dL, plaquettes 260 G/L."},
 hb:{l:"Hémoglobine",re:/hemoglobine|\bhb\b|hematocrite|\bht\b/,not:/electro|emmel/,n:"Hémoglobine : 13,0 g/dL."},
 glyc:{l:"Glycémie",re:/glyc|sucre|dextro|\bhgt\b/,n:"Glycémie : 5,0 mmol/L (4,0–6,1)."},
 crp:{l:"CRP",re:/\bcrp\b|proteine c|\bvs\b|sedimentation|inflammat/,n:"CRP : 4 mg/L (< 6)."},
 creat:{l:"Créatinine",re:/creat|fonction renale|insuffisance renale|\brenal/,n:"Créatinine : 80 µmol/L (60–110)."},
 uree:{l:"Urée",re:/uree|azot/,n:"Urée : 4,5 mmol/L (2,5–7,5)."},
 iono:{l:"Ionogramme",re:/iono|natremie|kaliemie|potassium|sodium|electrolyte|bicarb|reserve alcaline/,n:"Na 140, K 4,0, Cl 102 mmol/L : normaux."},
 foie:{l:"Bilan hépatique",re:/bilirub|bilan hepat|transaminase|\basat\b|\balat\b|\bast\b|\balt\b|hepatique/,n:"ASAT 28, ALAT 24 UI/L, bilirubine totale 12 µmol/L : normaux."},
 ecg:{l:"ECG",re:/\becg\b|electrocardio|trace cardiaque/,n:"ECG : rythme sinusal régulier, 78/min, sans anomalie."},
 rx:{l:"Radiographie du thorax",re:/telethorax|radio\w*\s*(du |des |de la )?(thorax|poumon|pulmon)|\brx\s*(du |des )?(thorax|poumon|pulmon)|radio\w*\s*thoracique|radio pulmonaire|radiographie pulmonaire|\brx thorax|\brx pulm/,n:"Radiographie du thorax : parenchyme pulmonaire et silhouette cardiaque normaux."},
 rxos:{l:"Radiographie osseuse",re:/radio\w*\s*(de |du |des |de la |d.)?(la |l.)?(jambe|tibia|perone|membre|osseuse|squelette|genou|cheville|femur|bassin|pied)|\brx\s*(de |du )?(jambe|tibia|membre|genou)|radiographie standard/,n:"Radiographie osseuse : pas de fracture ni de lésion osseuse."},
 asp:{l:"ASP (abdomen sans préparation)",re:/\basp\b|abdomen sans preparation|radio\w* (de l.)?abdom|radio\w* abdominale/,n:"ASP : pas de niveau hydro-aérique, pas de pneumopéritoine."},
 echoabdo:{l:"Échographie abdominale",re:/echo\w*\s*(de l.)?(abdom|abdo)|echo\w* abdominal|\becho abdo|echographie hepat|\bfast\b/,n:"Échographie abdominale : sans anomalie."},
 echogyn:{l:"Échographie pelvienne / obstétricale",re:/echo\w*\s*(pelvi|endovag|transvag|obstet|foetal|gyneco|de la grossesse)|echographie pelvienne|echographie obstetricale/,n:"Échographie pelvienne : utérus et annexes sans anomalie."},
 echocoeur:{l:"Échocardiographie",re:/echo\w*\s*(du |de )?(coeur|cardi)|echocardio|echo.?doppler cardiaque/,n:"Échocardiographie : cavités de taille normale, FEVG 60 %."},
 tdm:{l:"Scanner",re:/\btdm\b|scanner|tomodensito|\bct\b/,n:"Scanner : sans anomalie."},
 hemoc:{l:"Hémoculture",re:/hemoculture/,n:"Hémoculture : stérile à 48 h."},
 widal:{l:"Sérologie de Widal",re:/widal|serologie typh|test typhoide/,n:"Sérologie typhoïde : négative."},
 selles:{l:"Examen des selles",re:/selles|coproculture|parasitologie/,n:"Examen des selles : pas de parasite ni de sang."},
 ecbu:{l:"ECBU",re:/\becbu\b|culture.*urine|urines.*(culture|bacterio)|cytobacteriologique/,n:"ECBU : stérile."},
 bu:{l:"Bandelette urinaire",re:/bandelette|proteinurie|albuminurie|analyse d.urine|sediment|cetonurie|\burines\b/,n:"Bandelette urinaire : négative (pas de protéines, de sang ni de glucose)."},
 grp:{l:"Groupe sanguin / Rhésus",re:/groupe|rhesus|\brh\b|\babo\b|\brai\b|compatib/,n:"Groupe sanguin A Rh positif ; RAI négative."},
 vih:{l:"Test VIH",re:/\bvih\b|\bhiv\b|\bsida\b|retrovir/,n:"Test VIH : négatif."},
 genex:{l:"GeneXpert / crachats (BK)",re:/genexpert|gene xpert|crachat|\bbk\b|bacilloscopie|tuberculose|\bmtb\b|ziehl/,n:"GeneXpert : MTB non détecté."},
 electro:{l:"Électrophorèse de l'hémoglobine",re:/electrophorese|emmel|\bhbs\b|drepano|falciformation/,n:"Électrophorèse de l'hémoglobine : HbAA."},
 tropo:{l:"Troponine",re:/troponine|ck.?mb|marqueurs? cardiaques?/,n:"Troponine : normale."},
 lipase:{l:"Lipase / amylase",re:/lipase|amylase/,n:"Lipase : normale."},
 coag:{l:"Bilan de coagulation",re:/coagul|\btp\b|\btca\b|\binr\b|fibrinogene|hemostase/,n:"TP 95 %, TCA normal, fibrinogène 3,0 g/L."},
 bhcg:{l:"β-hCG / test de grossesse",re:/hcg|test de grossesse|\btg\b|\bbeta\b/,n:"β-hCG : négatif."},
 ponction:{l:"Ponction lombaire",re:/ponction lombaire|\bpl\b|\blcr\b|liquide cephalo/,n:"Ponction lombaire : LCR clair, normal."},
 gaz:{l:"Gaz du sang / lactate",re:/gaz du sang|gazometrie|\bgds\b|lactate/,n:"Gaz du sang : pH 7,40, lactate 1,2 mmol/L."},
 fogd:{l:"Endoscopie digestive haute (FOGD)",re:/fogd|endoscopie|gastroscopie|fibroscopie|oeso.?gastro/,n:"FOGD : muqueuse œsogastroduodénale normale."},
 pascite:{l:"Ponction d'ascite",re:/ponction d.ascite|liquide d.ascite|ponction ascit/,n:"Liquide d'ascite : jaune citrin, stérile, pas de cellule anormale."},
 alb:{l:"Albuminémie / protéines totales",re:/albumin|proteines totales|proteinemie|protidemie/,n:"Albumine : 40 g/L (35–50)."},
 hbs:{l:"Sérologie hépatites B et C",re:/\bhbs\b|hepatite b|hepatite c|serologie hepat|\bvhb\b|\bvhc\b/,n:"Ag HBs négatif, anticorps anti-VHC négatif."},
 aslo:{l:"ASLO / complément",re:/aslo|antistreptolysine|streptocoque|complement|\bc3\b/,n:"ASLO : normal ; C3 normal."},
 dopptest:{l:"Échographie-doppler scrotale",re:/doppler testic|echo\w*\s*(de |du |des )?(scrot|testic|bourse)|echo.?doppler scrot/,n:"Échographie-doppler scrotale : testicules et épididymes normaux, vascularisation conservée."},
 echouro:{l:"Échographie de l'appareil urinaire",re:/echo\w*\s*(de |du |des )?(l.)?(appareil )?(urinaire|renale|reins|vesic|prostat)|echographie renale|echo reno|echo vesico/,n:"Échographie rénale et vésicale : sans anomalie."},
 psa:{l:"PSA",re:/\bpsa\b|antigene prostatique/,n:"PSA : 1,8 ng/mL (normal pour l'âge)."}
};

/* =====================================================================
   QUESTIONS GÉNÉRIQUES DU PATIENT (identité, contexte : valables pour tous les cas)
   ===================================================================== */
var GEN=[
 ["salut",/^(bonjour|bonsoir|salut|bonne)/,function(){return "Bonjour docteur.";}],
 ["motif",/motif|pleinte|plinte|plainte|pourquoi|prkoi|pourqoi|qu.est.ce qui (vous )?amene|plainte|raconte|pourquoi (venez|etes)/,function(p,d){return d.plainte;}],
 ["nom",/\bnom\b|appelez|prenom/,function(p){return p.kid?"Il s'appelle "+p.prenom+".":"Je m'appelle "+p.prenom+".";}],
 ["age",/\bage\b|quel age|\bans\b|naissance/,function(p){return p.kid?p.Pron+" a "+p.age+".":"J'ai "+p.age+".";}],
 ["pro",/profession|travail|metier|activite|ecole|que faites|vous faites/,function(p){return p.kid?p.Pron+" "+p.pro+".":"Je suis "+p.pro+".";}],
 ["habitat",/habit|quartier|commune|domicile|logement/,function(p){return p.kid?"Nous habitons à "+p.commune+".":"J'habite à "+p.commune+".";}],
 ["allerg",/allerg/,function(){return "Pas d'allergie connue.";}],
 ["tabac",/tabac|fume|cigarette|alcool|boisson alcool|drogue/,function(p){return p.kid?"Non, ce n'est pas concerné, c'est un enfant.":"Je ne fume pas et je ne bois pas d'alcool.";}],
 ["fam",/famille|familiaux|heredit|frere|soeur/,function(){return "Rien de particulier dans la famille.";}],
 ["vacc",/vaccin/,function(p){return p.kid?"Les vaccins du PEV sont à jour.":"Je ne sais pas, je n'ai pas de carnet.";}],
 ["trait",/traitement|medicament|prend|prenez|\bpris\b|automedic/,function(){return "Rien de particulier, à part du paracétamol de temps en temps.";}],
 ["atcd",/atcd|antecedent|antecedents|maladie|hospital|operat|chirurg|deja eu/,function(){return "Rien de particulier : pas de maladie connue ni d'opération.";}],
 ["vih",/\bvih\b|\bsida\b|depist/,function(){return "Pas à ma connaissance.";}]
];

/* Réponses négatives par défaut : le patient nie un symptôme que le cas ne mentionne pas.
   [id, mots-clés, réponse adulte, réponse enfant (facultative)] */
var LEXNEG=[
 ["fievre",/fievre|frisson|temperature|febrile/,"Non, pas de fièvre."],
 ["toux",/\btoux\b|tousse|crach|expector/,"Non, pas de toux."],
 ["vomi",/vomi|nausee/,"Non, pas de vomissements."],
 ["diarr",/diarrhee|\bselles?\b|caca/,"Non, pas de diarrhée, les selles sont normales."],
 ["constip",/constipation/,"Non, pas de constipation."],
 ["cephal",/cephal|maux de tete|migraine/,"Non, pas de mal de tête.","Non, {pron} ne se plaint pas de la tête."],
 ["thorax",/poitrine|thorax|oppression/,"Non, pas de douleur à la poitrine.","Non, {pron} ne se plaint pas de la poitrine."],
 ["dyspnee",/essouff|dyspnee|respir|souffle/,"Non, je respire normalement.","Non, {pron} respire normalement."],
 ["palpit",/palpit/,"Non, pas de palpitations."],
 ["vertige",/vertige|etourd/,"Non, pas de vertiges.","Non, pas de malaise."],
 ["malaise",/malaise|syncope|evanou/,"Non, pas de malaise."],
 ["convuls",/convuls|epilep/,"Non, pas de convulsions."],
 ["saign",/saign|\bsang\b|hemorragie/,"Non, pas de saignement."],
 ["urine",/urine|pipi|miction/,"Non, rien d'anormal du côté des urines."],
 ["jaune",/jaune|ictere/,"Non, pas de jaunisse."],
 ["oedeme",/oedeme|gonfl|enfle/,"Non, rien n'est gonflé."],
 ["poids",/maigri|perte de poids|amaigr/,"Non, mon poids n'a pas changé.","Non, son poids n'a pas changé."],
 ["appetit",/appetit|\bfaim\b/,"Mon appétit est normal.","{pron} mange normalement."],
 ["sueurs",/sueur|transpir/,"Non, pas de sueurs particulières."],
 ["eruption",/eruption|bouton|demangeaison|prurit/,"Non, pas de boutons sur la peau."],
 ["gorge",/\bgorge\b|angine/,"Non, pas de mal de gorge.","Non, {pron} avale normalement."],
 ["abdo",/ventre|abdom|estomac/,"Non, pas de douleur au ventre.","Non, {pron} ne se tient pas le ventre."],
 ["dos",/\bdos\b|lombaire|\breins?\b/,"Non, pas de douleur au dos.","Non, {pron} ne se plaint pas du dos."],
 ["articul",/articulation|\bos\b/,"Non, pas de douleur dans les articulations.","Non, {pron} marche normalement."],
 ["vue",/\bvue\b|vision/,"Non, ma vue est normale.","Je ne sais pas, c'est un petit."],
 ["faible",/paralys|faiblesse|parole|bouche tordue/,"Non, pas de faiblesse, et je parle normalement.","Non, {pron} bouge normalement."],
 ["soif",/\bsoif\b/,"Pas plus soif que d'habitude."]
];

/* Synonymes : une expression libre est ramenée aux mots-clés que les dossiers comprennent. */
var SYN=[
 [/mal (a|au|aux|dans) (la |le |les |l')?(tete|crane)|migraine|tete (qui )?(fait mal|cogne|eclate)|maux de tete/,"cephal tete maux de tete"],
 [/mal (a|au|dans) (le |l')?(ventre|estomac|abdomen)|douleurs? (du |au |de l')?(ventre|estomac|abdomen)|ventre (qui )?(fait mal|gonfle|dur)/,"abdom ventre"],
 [/mal (a|au|dans) (la |le |l')?(poitrine|thorax|coeur)|douleurs? (de la |du |a la |au )?(poitrine|thorax|coeur)|oppression|serrement/,"thorax poitrine"],
 [/corps chaud|chaleur|frisson|febrile|fievre|temperature|chaud/,"fievre frisson temperature"],
 [/(difficulte|mal|peine) (a|pour) respirer|manque d.air|etouff|essouffl|souffle court|respire (vite|mal)|respiration/,"respir souffle essouff dyspnee"],
 [/gonfl|enfl|oedeme|tumef/,"oedeme gonfl enfle"],
 [/maigr|amaigr|perdu du poids|perte de poids|poids/,"maigri poids"],
 [/pas faim|plus faim|appetit|\bmange|manger|alimentation|nourriture|repas|\bfaim\b/,"appetit mange manger alimentation repas"],
 [/urine|uriner|pipi|miction|vessie|petit besoin/,"urine pipi uriner miction"],
 [/saign|\bsang\b|hemorragie/,"saign sang"],
 [/jaun|ictere|yeux jaunes|peau jaune/,"jaune ictere yeux"],
 [/malaise|evanou|syncope|perdu connaissance|perte de connaissance|dans les pommes/,"malaise conscien syncope evanou"],
 [/convuls|secousse|epilep|mouvements anormaux|raidi/,"convuls crise secousse"],
 [/vomi|nausee|envie de vomir|ecoeur|rejette/,"vomi nausee"],
 [/diarrhee|selles? liquides?|ventre qui coule|va souvent a la selle|caca liquide|\bselles?\b|transit/,"diarrhee selle transit caca"],
 [/constipa|(pas|plus) de selles?|pas (all|aller)\w* a la selle/,"constipation selle transit"],
 [/\btou(x|sse|sses)\b|crach|expector|glaires/,"toux tousse crach"],
 [/vertige|tete qui tourne|etourdi|tourne la tete|ca tourne/,"vertige etourd"],
 [/mal (a|de|dans) (la |ma )?gorge|angine|avaler|deglut/,"gorge orl angine"],
 [/medicament|comprime|cachet|pilule|sirop|piqure|injection|soigne|tisane|automedic|pharmacie|traitement/,"medicament traitement pris automed"],
 [/(ca|cela|il|elle) (dure|date)|depuis (combien|quand)|quand est.ce que|combien de (jours|semaines|temps)|depuis longtemps|a commence/,"depuis quand debut"],
 [/ou (avez.vous|as.tu) mal|ou ca fait mal|ou est la douleur|a quel endroit|quel endroit/,"douleur localis"],
 [/irradi|ca (descend|monte|se propage)/,"irradi"],
 [/eruption|boutons?|plaques?|rougeur|demangeaison|prurit/,"eruption bouton peau"],
 [/mal (au|dans le|aux) (dos|reins|lombes)|lombalgie/,"dos lombaire rein"],
 [/mal (aux|dans les|a l') ?(os|articulations?|jambes?|bras|genou)|douleur osseuse/,"os articul jambe bras"],
 [/\bvue\b|\bvoir\b|vision/,"vue vision"],
 [/paralys|faiblesse|bouger (le |la |son |sa )?(bras|jambe|main)|parole|parler|bouche (de travers|tordue)/,"paralys faiblesse parole bouche"],
 [/quelqu.un (de |dans )?(malade|qui tousse)|entourage|contact/,"contact entourage"],
 [/rapports?|sexuel|partenaire|preservatif|mari\b|epoux/,"rapport sexuel partenaire"],
 [/malade|maladie|infection|souffr|contagi/,"maladie infection antecedent"],
 [/\batcd\b|antecedent|antecedents/,"antecedent atcd"],
 [/\beau\b|puits|robinet|latrines?|hygiene|\bboit|boire/,"eau hygiene boire"]
];
function expand(t){
  var add="";
  SYN.forEach(function(s){if(s[0].test(t))add+=" "+s[1];});
  return add?t+" "+add:t;
}

/* Mots d'accompagnement (début, durée, couleur…) : ils précisent un symptôme mais ne suffisent pas à choisir une réponse. */
var WEAKS=["mal","depuis quand","debut","quand","combien de temps","comment","combien","quantite","couleur","aspect","frequence","localis","irradi","abondan","brutal","soudain","intense","caillot","combien de fois","duree","evolution","depuis","pourquoi","cause","avant","declench","rythme","intermittent","nombril","droite","migr","position","hier","aujourd"];
var ALTC={};
function splitAlts(src){
  var out=[],cur="",depth=0,cls=false;
  for(var i=0;i<src.length;i++){
    var c=src.charAt(i);
    if(c==="\\"){cur+=c+(src.charAt(i+1)||"");i++;continue;}
    if(cls){cur+=c;if(c==="]")cls=false;continue;}
    if(c==="["){cls=true;cur+=c;continue;}
    if(c==="(")depth++;
    if(c===")")depth--;
    if(c==="|"&&depth===0){out.push(cur);cur="";continue;}
    cur+=c;
  }
  out.push(cur);
  return out;
}
function mkAlts(re){
  var k=re.source;
  if(!ALTC[k]){
    ALTC[k]=splitAlts(k).map(function(a){
      var plain=a.replace(/\\b/g,"").replace(/\\/g,"").trim();
      return {re:new RegExp(a),weak:WEAKS.indexOf(plain)>=0};
    });
  }
  return ALTC[k];
}
function scoreEntry(re,t){
  var al=mkAlts(re),strong=0,weak=0,pos=1e9,hits=[];
  for(var i=0;i<al.length;i++){
    var m=al[i].re.exec(t);
    if(!m)continue;
    if(al[i].weak)weak++;
    else{strong++;hits.push(m[0]);if(m.index<pos)pos=m.index;}
  }
  return {strong:strong,weak:weak,pos:pos,hits:hits};
}
var STOPW={docteur:1,depuis:1,pouvez:1,combien:1,quelle:1,quelles:1,quels:1,votre:1,aviez:1,faites:1,avez:1,vous:1,est:1,etes:1,avoir:1,pensez:1,savez:1,dites:1,pourriez:1,voulez:1,souhaitez:1,quand:1};
function fallbackReply(t0){
  // Version tolérante : jamais bloquante, redonne la plainte principale
  var d=null; try{ d=DB[S.did]; }catch(e){}
  var base = d && d.plainte ? d.plainte : "Je suis là pour répondre à vos questions, docteur.";
  // Si mot proche de motif/antecedent, on aide
  if(/antecedent|atcd|atcdts/.test(t0)) return d ? "Pour les antécédents : " + (d.hist.find(function(e){return e[0]==="atcd";}) ? d.hist.find(function(e){return e[0]==="atcd";})[3] : "Pas d'antécédent particulier, à part ce que je vous ai déjà dit.") + " " + base : base;
  if(/plainte|pleinte|motif|pourquoi|venez/.test(t0)) return base;
  return base + " Pouvez-vous préciser votre question (fièvre, douleur, depuis quand, médicaments, antécédents) ?";
}

/* =====================================================================
   BASE DES CAS PAR SERVICE
   hist : [id, libellé, regex, réponse, essentiel(1)]
   ===================================================================== */

var D=[];
var DB={};
function loadCases(){
  var s=document.createElement('script');
  s.src='./cases_202.js?v='+Date.now();
  s.onload=function(){
    console.log('202 cas chargés JS', D.length);
    if(typeof render==='function') try{render();}catch(e){console.error(e);}
    var kpi=document.getElementById('kpi-total'); if(kpi) kpi.textContent=D.length;
    try{ document.querySelectorAll('.small.muted').forEach(function(el){ if(el.textContent.includes('cas pour')) el.textContent = D.length+' cas pour l\'instant, répartis par service. Le patient et les valeurs changent à chaque fois, d\'autres cas seront ajoutés.'; }); }catch(e){}
  };
  s.onerror=function(){ console.error('Erreur chargement cases_202.js'); };
  document.head.appendChild(s);
}
loadCases();
var _retry=0;
var _int=setInterval(function(){
  try{
    if(typeof D!=="undefined" && D.length>0){
      clearInterval(_int);
      console.log('D ready', D.length);
      if(typeof render==='function') render();
    } else {
      _retry++;
      if(_retry>10){ clearInterval(_int); console.warn('D still 0 after retry'); }
    }
  }catch(e){ console.error(e); }
}, 600);





/* =====================================================================
   ÉTAT
   ===================================================================== */
function load(k){try{return JSON.parse(localStorage.getItem(k));}catch(e){return null;}}
function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){} try{if(window._fbSync)window._fbSync(k,v);}catch(e){}}
function wipe(k){try{localStorage.removeItem(k);}catch(e){}}

var S=load(KEY); if(S&&(!S.did||!DB[S.did]||!S.chat))S=null;
var hist=load(HKEY); if(!Array.isArray(hist))hist=[];
window._fbReloadHist = function(){ try{ hist=load(HKEY); if(!Array.isArray(hist))hist=[]; if(typeof render==='function') render(); }catch(e){} };
window._fbGetHist = function(){ return hist; };
window._fbSetHist = function(h){ hist=h; save(HKEY,hist); if(typeof render==='function') render(); };
try{ if(S && (!S.did || typeof DB==="undefined" || !DB[S.did])){ localStorage.removeItem(KEY); localStorage.removeItem(HKEY); S=null; } }catch(e){}
var view="home";
var busy=false, pending=null, err="", confirmWipe=false;
var draft={svc:SERVICES[0],chat:"",exam:"",para:"",dx:"",tx:"",ori:ORIS[1]};

var app=document.getElementById("app");
var navCase=document.getElementById("nav-case"), navProg=document.getElementById("nav-prog");

function h(tag,attrs){
  var e=document.createElement(tag);
  if(attrs){for(var k in attrs){var v=attrs[k];
    if(v===false||v==null)continue;
    if(k==="class")e.className=v;
    else if(k==="style"&&typeof v==="object")Object.assign(e.style,v);
    else if(k.indexOf("on")===0)e.addEventListener(k.slice(2),v);
    else if(v===true)e.setAttribute(k,"");
    else e.setAttribute(k,v);}}
  for(var i=2;i<arguments.length;i++){
    var kids=[].concat(arguments[i]);
    for(var j=0;j<kids.length;j++){var c=kids[j];if(c==null||c===false)continue;e.append(typeof c==="object"?c:String(c));}
  }
  return e;
}
function delay(ms){return new Promise(function(r){setTimeout(r,ms);});}

/* =====================================================================
   MOTEUR : patient, examens, résultats
   ===================================================================== */
function mkPatient(d){
  var p=d.pt,m=p.s==="M";
  var pool=p.kid?(m?KM:KF):(m?NM:NF);
  var age=typeof p.age==="string"?p.age:(rnd(p.age[0],p.age[1])+" ans");
  return {prenom:pick(pool),sexe:m?"Masculin":"Féminin",age:age,pro:pick(p.pro),commune:pick(COMMUNES),Pron:m?"Il":"Elle",kid:!!p.kid};
}
function fill(t,p){return String(t).replace(/\{(\w+)\}/g,function(m,k){return p[k]!=null?p[k]:m;});}

/* Le patient lit les mots-clés de la question (après synonymes), classe les réponses du dossier par pertinence, puis complète par le contexte général et par des réponses négatives. */
function patientReply(S,q){
  var d=DB[S.did],p=S.pt,t0=N(q),t=expand(t0);
  var hello=GEN[0][1].test(t0)?"Bonjour docteur.":"";
  var own={},cands=[],weakOnly=[];
  function consider(id,re,fn,isCase){
    var s=scoreEntry(re,t);
    if(s.strong>0)cands.push({id:id,fn:fn,score:s.strong+0.35*s.weak,pos:s.pos,hits:s.hits});
    else if(isCase&&s.weak>0)weakOnly.push({id:id,fn:fn});
  }
  d.hist.forEach(function(e){own[e[0]]=1;consider(e[0],e[2],function(){return fill(e[3],p);},true);});
  GEN.forEach(function(g){if(g[0]==="salut"||own[g[0]])return;consider(g[0],g[1],function(){return g[2](p,d);},false);});

  var chosen=[];
  if(cands.length){
    var max=0;cands.forEach(function(c){if(c.score>max)max=c.score;});
    chosen=cands.filter(function(c){return c.score>=max*0.5;});
    chosen.sort(function(a,b){return b.score-a.score||a.pos-b.pos;});
    chosen=chosen.slice(0,4).sort(function(a,b){return a.pos-b.pos;});
  }
  var out=chosen.map(function(c){return c.fn();}),ids=chosen.map(function(c){return c.id;});

  if(out.length<4){
    LEXNEG.forEach(function(l){
      if(out.length>=4)return;
      var m=l[1].exec(t);if(!m)return;
      if(chosen.some(function(c){return c.hits.some(function(h){return l[1].test(h);});}))return;
      if(out.some(function(o){return l[1].test(N(o));}))return;
      if(d.hist.some(function(e){return e[2].test(m[0]);}))return;
      var ent=d.hist.filter(function(e){return ids.indexOf(e[0])<0&&l[1].test(N(fill(e[3],p)));})[0];
      if(ent){out.push(fill(ent[3],p));ids.push(ent[0]);return;}
      if(l[1].test(N(d.plainte))){out.push(d.plainte);ids.push("motif");return;}
      out.push(fill(p.kid&&l[3]?l[3]:l[2],Object.assign({},p,{pron:String(p.Pron).toLowerCase()})));ids.push("sx_"+l[0]);
    });
  }
  if(!out.length&&weakOnly.length){out.push(weakOnly[0].fn());ids.push(weakOnly[0].id);}
  if(!out.length&&!hello){
    if(/depuis quand|quand (ca|cela|est|a)|debut|commence|combien de temps/.test(t0))out.push(p.kid?"Ça a commencé il y a quelques jours, docteur. Je peux vous en dire plus si vous me posez une question précise.":"Ça a commencé il y a quelques jours, docteur. Demandez-moi quelque chose de plus précis, je vous répondrai.");
    else out.push(fallbackReply(t0));
  }
  return {text:((hello?hello+" ":"")+out.join(" ")).trim(),ids:ids};
}
function examReply(S,q){
  var d=DB[S.did],t=N(q),found=[];
  EXORDER.forEach(function(id){if(EX[id].re.test(t))found.push(id);});
  if(!found.length)return {text:"Je n'ai pas compris ce que tu examines. Précise, par exemple : constantes, cœur, poumons, abdomen, neurologique.",ids:[]};
  var lines=found.map(function(id){return EX[id].l+" : "+(d.ex[id]||EX[id].n);});
  if(d.exBad&&d.exBad.re.test(t))lines.push(d.exBad.msg);
  return {text:lines.join("\n"),ids:found};
}
function paraReply(S,q){
  var d=DB[S.did],lines=[],ids=[],unk=[];
  var chunks=q.split(/[,;\n+]| et | puis /i).map(function(s){return s.trim();}).filter(Boolean);
  chunks.forEach(function(c){
    var t=N(c),hit=[];
    TORDER.forEach(function(id){var T=TESTS[id];if(T.re.test(t)&&!(T.not&&T.not.test(t)))hit.push(id);});
    if(!hit.length&&/echo/.test(t))hit.push(d.eDef||"echoabdo");
    if(!hit.length)unk.push(c);
    hit.forEach(function(id){ids.push(id);lines.push(d.res[id]||TESTS[id].n);});
  });
  unk.forEach(function(c){lines.push("Examen non reconnu : « "+c+" ». Reformule avec le nom de l'examen.");});
  return {text:lines.join("\n"),ids:uniq(ids)};
}

/* =====================================================================
   NOTATION PAR RÈGLES
   ===================================================================== */
function round(x){return Math.max(0,Math.min(10,Math.round(x)));}
function labelsOf(arr,max){var s=arr.slice(0,max).join(" ; ");return arr.length>max?s+" ; …":s;}
function evaluate(S){
  var d=DB[S.did],asked=S.asked||[],exIds=S.examIds||[],tIds=S.testIds||[];
  var essH=d.hist.filter(function(e){return e[4];});
  var missH=essH.filter(function(e){return asked.indexOf(e[0])<0;}).map(function(e){return e[1];});
  var hitH=essH.length-missH.length;
  var nQ=S.chat.filter(function(m){return m.r==="d";}).length;
  var sInt=round(10*hitH/essH.length); if(nQ<3)sInt=Math.min(sInt,2);

  var missE=d.exEss.filter(function(id){return exIds.indexOf(id)<0;}).map(function(id){return EX[id].l;});
  var hitE=d.exEss.length-missE.length;
  var sEx=round(10*hitE/d.exEss.length);
  var exBadHit=!!(d.exBad&&(S.exams||[]).some(function(x){return d.exBad.re.test(N(x.q));}));
  if(exBadHit)sEx=Math.max(0,sEx-4);

  var keyIds=[];d.key.forEach(function(g){keyIds=keyIds.concat(g);});
  var allowed=keyIds.concat(d.useful);
  var missT=d.key.filter(function(g){return !g.some(function(id){return tIds.indexOf(id)>=0;});}).map(function(g){return TESTS[g[0]].l;});
  var hitT=d.key.length-missT.length;
  var useless=tIds.filter(function(id){return allowed.indexOf(id)<0;}).map(function(id){return TESTS[id].l;});
  var sPara;
  if(d.key.length){sPara=tIds.length?10*hitT/d.key.length-useless.length:0;}
  else sPara=10-2*useless.length;
  sPara=round(sPara);

  var dxN=N(S.dx),sDx=0,dxState="none";
  if(d.dx.full.test(dxN)){sDx=10;dxState="full";}
  else if(d.dx.part.test(dxN)){sDx=d.dx.pts;dxState="part";}

  var txN=N(S.tx),totW=0,gotW=0,missX=[];
  d.tx.forEach(function(it){totW+=it[2];if(it[1].test(txN))gotW+=it[2];else missX.push(it[0]);});
  var oriOk=d.ori.indexOf(ORIS.indexOf(S.ori))>=0;
  var pen=0,badHit=[];
  (d.bad||[]).forEach(function(b){if(b[1].test(txN)){pen+=b[2];badHit.push(b[0]);}});
  var sTx=round(8*gotW/totW+(oriOk?2:0)-pen);

  var scores={interrogatoire:sInt,examen_clinique:sEx,examens_complementaires:sPara,diagnostic:sDx,traitement:sTx};
  var total=(sInt+sEx+sPara+sDx+sTx)*2;

  var com={};
  com.interrogatoire=hitH+"/"+essH.length+" points essentiels abordés."+(missH.length?" Il manquait : "+labelsOf(missH,3)+".":"")+(nQ<3?" Pose au moins quelques questions avant de passer à l'examen.":"");
  com.examen_clinique=hitE+"/"+d.exEss.length+" systèmes essentiels examinés."+(missE.length?" Il manquait : "+labelsOf(missE,3)+".":"")+(exBadHit?" "+d.exBad.short:"");
  com.examens_complementaires=(d.key.length?hitT+"/"+d.key.length+" examens clés demandés.":(d.paraNote||""))+(missT.length?" Il manquait : "+labelsOf(missT,3)+".":"")+(useless.length?" Examens peu utiles ici : "+labelsOf(useless,3)+".":"");
  com.diagnostic=dxState==="full"?"Diagnostic exact : "+d.name+".":dxState==="part"?"Diagnostic incomplet : il fallait aller jusqu'à « "+d.name+" ».":"Diagnostic attendu : "+d.name+".";
  com.traitement=(totW?Math.round(100*gotW/totW)+" % des éléments de la prise en charge retrouvés.":"")+(missX.length?" Manquait : "+labelsOf(missX,3)+".":"")+(badHit.length?" À éviter : "+badHit.join(" ; ")+".":"")+(oriOk?" Orientation correcte.":" Orientation attendue : "+d.ori.map(function(i){return ORIS[i];}).join(" ou ")+".");

  var verdict=total>=80?"Très bonne consultation : démarche structurée et conduite à tenir correcte.":total>=60?"Consultation satisfaisante, avec quelques points à compléter.":total>=40?"Démarche incomplète : reprends les points signalés ci-dessous.":"Consultation insuffisante : revois la sémiologie et la conduite à tenir de cette maladie.";

  var forts=[],amel=[];
  AXES.forEach(function(a){var s=scores[a[0]];if(s>=7)forts.push(a[1]+" : "+s+"/10.");else if(s<6)amel.push(a[1]+" : "+s+"/10. "+com[a[0]]);});

  return {scores:scores,total:total,d:{
    verdict:verdict,commentaires:com,points_forts:forts,a_ameliorer:amel,
    questions_manquantes:missH.concat(missE.map(function(x){return "Examen : "+x;}),missT.map(function(x){return "Examen demandé : "+x;}),missX),
    explication:d.expl,differentiels_a_ecarter:d.diffs,traitement_attendu:d.txText,a_reviser:d.rev,pieges:d.pieges}};
}

/* =====================================================================
   NAVIGATION
   ===================================================================== */
function go(v){view=v;confirmWipe=false;err="";render();window.scrollTo(0,0);}
navCase.addEventListener("click",function(){go(S&&!S.done?"case":"home");});
navProg.addEventListener("click",function(){go("progress");});

function level(t){return t>=80?["Très bon","good"]:t>=60?["Satisfaisant","ok"]:t>=40?["À consolider","warn"]:["Insuffisant","bad"];}
function fmtDate(t){return new Date(t).toLocaleDateString("fr-FR",{day:"2-digit",month:"2-digit"});}

/* =====================================================================
   ACCUEIL
   ===================================================================== */
function homeView(){
  var root=h("div",{class:"stack"});
  root.append(h("div",{class:"hero"},
    h("h1",null,"Reçois un patient, mène la consultation."),
    h("p",{class:"muted"},"Interroge, examine, demande tes examens, conclus. L'évaluation te dit ce qui était juste et ce qui manquait.")));

  if(S&&!S.done){
    var d0=DB[S.did];
    root.append(h("section",{class:"card"},
      h("div",{class:"label"},"Cas en cours"),
      h("p",null,S.pt.prenom+" · "+d0.svc+", étape « "+STEPS[S.stage]+" »"),
      h("div",{class:"row"},
        h("button",{class:"btn",type:"button",onclick:function(){go("case");}},"Reprendre"),
        h("button",{class:"btn ghost",type:"button",onclick:function(){S=null;wipe(KEY);render();}},"Abandonner"))));
  }

  var svc=h("select",{id:"svc",onchange:function(e){draft.svc=e.target.value;}},SERVICES.map(function(s){return h("option",{value:s,selected:s===draft.svc},s);}));
  root.append(h("section",{class:"card"},
    h("h2",null,"Nouveau cas"),
    h("div",{class:"field"},h("label",{class:"label",for:"svc"},"Service"),svc),
    h("div",{class:"row"},h("button",{class:"btn",type:"button",onclick:startCase},"Recevoir un patient")),
    h("p",{class:"small muted"},(typeof D!=="undefined"?D.length:208)+" cas pour l'instant, répartis par service. Le patient et les valeurs changent à chaque fois, d'autres cas seront ajoutés.")));

  if(S&&S.done&&S.ev)root.append(h("button",{class:"btn ghost",type:"button",onclick:function(){go("eval");}},"Revoir la dernière évaluation"));
  return root;
}
function startCase(){
  var pool=D.filter(function(d){return draft.svc===SERVICES[0]||d.svc===draft.svc;});
  var last=hist.length?hist[hist.length-1].did:null;
  var cand=pool.filter(function(d){return d.id!==last;});
  var d=pick(cand.length?cand:pool);
  var pt=mkPatient(d);
  S={t:Date.now(),did:d.id,pt:pt,stage:0,maxStage:0,done:false,
     chat:[{r:"p",t:d.plainte}],exams:[],paras:[],asked:[],examIds:[],testIds:[],hyp:"",dx:"",tx:"",ori:ORIS[1],ev:null};
  draft.chat=draft.exam=draft.para=draft.dx=draft.tx="";draft.ori=ORIS[1];
  save(KEY,S);view="case";err="";render();window.scrollTo(0,0);
}

/* =====================================================================
   CONSULTATION
   ===================================================================== */
function patientCard(){
  var d=DB[S.did],p=S.pt;
  var isKid = !!p.kid;
  var sexe = p.sexe || (p.s==='F'?'F':'M');
  var avatarClass = isKid ? 'kid' : (sexe==='F' ? 'f' : 'm');
  var avatarIcon = isKid ? '👶' : (sexe==='F' ? '👩' : '👨');
  var ageText = p.age || '';
  var prenomText = p.prenom || (isKid ? 'Enfant' : (sexe==='F' ? 'Patiente' : 'Patient'));
  var communeText = p.commune || '';
  
  // Avatar element
  var avatarEl = h("div",{class:"pt-avatar-wrap"},
    h("div",{class:"pt-avatar "+avatarClass},
      h("span",{class:"pt-avatar-icon"}, avatarIcon)
    )
  );
  
  // Info element
  var infoEl = h("div",{class:"pt-info"},
    h("div",{class:"label"}, isKid ? "Enfant reçu avec sa mère" : (sexe==='F' ? "Patiente reçue" : "Patient reçu")),
    h("div",{class:"pt-main"},
      h("div",{class:"name"}, [prenomText, ageText, sexe].filter(Boolean).join(" · ")),
      h("span",{class:"pt-badge-age"}, "🎂 "+ageText)
    ),
    h("div",{class:"muted"}, communeText),
    h("div",{class:"tags"},
      h("span",{class:"tag"}, d.svc),
      isKid ? h("span",{class:"tag", style:{background:"var(--warn-soft)", borderColor:"var(--warn)", color:"var(--warn)"}}, "Pédiatrie") : null
    )
  );
  
  return h("section",{class:"card pt"}, avatarEl, infoEl);
}
function stepper(){
  var ol=h("ol",{class:"steps"});
  STEPS.forEach(function(name,i){
    var cls=i===S.stage?"cur":(i<S.stage?"done":"");
    ol.append(h("li",null,h("button",{type:"button",class:cls,disabled:i>S.maxStage,"aria-current":i===S.stage?"step":false,
      onclick:function(){S.stage=i;save(KEY,S);render();}},name)));
  });
  return ol;
}
function caseView(){
  var root=h("div",{class:"stack"});
  root.append(patientCard(),stepper());
  root.append([chatPanel,examPanel,paraPanel,conclPanel][S.stage]());
  return root;
}
function nextStage(){S.stage=Math.min(3,S.stage+1);S.maxStage=Math.max(S.maxStage,S.stage);save(KEY,S);render();window.scrollTo(0,0);}
function prevStage(){S.stage=Math.max(0,S.stage-1);save(KEY,S);render();window.scrollTo(0,0);}
function navRow(next){
  return h("div",{class:"row between"},
    S.stage>0?h("button",{class:"btn ghost",type:"button",disabled:busy,onclick:prevStage},"← Retour"):h("span"),
    next?h("button",{class:"btn ghost",type:"button",disabled:busy,onclick:nextStage},next+" →"):null);
}
function composer(id,key,placeholder,label,onSend,chips){
  var ta=h("textarea",{id:id,rows:"3",placeholder:placeholder,disabled:busy,
    oninput:function(e){draft[key]=e.target.value;},
    onkeydown:function(e){if((e.ctrlKey||e.metaKey)&&e.key==="Enter"){e.preventDefault();onSend();}}});
  ta.value=draft[key];
  var chipRow=chips?h("div",{class:"chips"},chips.map(function(c){
    return h("button",{class:"chip",type:"button",disabled:busy,onclick:function(){
      draft[key]=(draft[key].trim()?draft[key].trim()+(key==="chat"?" ":", "):"")+c;ta.value=draft[key];ta.focus();}},c);
  })):null;
  return h("div",{class:"field",id:"compose"},
    h("label",{class:"label",for:id},label),chipRow,ta,
    h("div",{class:"row"},h("button",{class:"btn",type:"button",disabled:busy,onclick:onSend},"Envoyer")));
}
function afterSend(){var el=document.getElementById("compose");if(el)el.scrollIntoView({block:"end"});}

/* Étape 1 : interrogatoire */
function bubble(m){
  var d=DB[S.did];
  return h("div",{class:"bubble "+m.r},h("span",{class:"who"},m.r==="d"?"Toi":d.who),m.t);
}
function chatPanel(){
  var d=DB[S.did];
  var log=h("div",{class:"chat"},S.chat.map(bubble));
  if(pending==="chat")log.append(h("div",{class:"bubble p pending"},h("span",{class:"who"},d.who),"…"));
  return h("section",{class:"card"},
    h("h2",null,"Interrogatoire"),
    h("p",{class:"small muted"},"Écris tes questions librement, comme en consultation. Le patient repère les mots-clés (fièvre, toux, depuis quand, médicaments, antécédents…) et répond en conséquence. Pose une ou deux questions à la fois."),
    log,
    composer("chat-in","chat","Pose ta question au patient…","Ta question",sendChat,CHAT_CHIPS),
    navRow("Examen clinique"));
}
async function sendChat(){
  var t=draft.chat.trim();if(!t||busy)return;
  S.chat.push({r:"d",t:t});draft.chat="";save(KEY,S);
  pending="chat";busy=true;render();afterSend();
  await delay(450);
  var r=patientReply(S,t);
  S.chat.push({r:"p",t:r.text});S.asked=uniq((S.asked||[]).concat(r.ids));
  pending=null;busy=false;save(KEY,S);render();afterSend();
}

/* Étape 2 : examen clinique */
function entries(list,prefix){
  return list.map(function(x){return h("div",{class:"entry"},h("div",{class:"q"},prefix+x.q),h("div",{class:"res"},x.a));});
}
function examPanel(){
  var log=h("div",{class:"stack"},entries(S.exams,"Examiné : "));
  if(pending==="exam")log.append(h("div",{class:"entry"},h("div",{class:"res pending"},"…")));
  return h("section",{class:"card"},
    h("h2",null,"Examen clinique"),
    h("p",{class:"small muted"},"Dis ce que tu examines. Tu ne reçois que les constatations des gestes demandés."),
    log,
    composer("exam-in","exam","Ex : constantes, auscultation du cœur et des poumons, palpation de l'abdomen","Ce que tu examines",sendExam,EXAM_CHIPS),
    navRow("Examens complémentaires"));
}
async function sendExam(){
  var t=draft.exam.trim();if(!t||busy)return;
  pending="exam";busy=true;render();afterSend();
  await delay(450);
  var r=examReply(S,t);
  S.exams.push({q:t,a:r.text});S.examIds=uniq((S.examIds||[]).concat(r.ids));
  draft.exam="";pending=null;busy=false;save(KEY,S);render();afterSend();
}

/* Étape 3 : examens complémentaires */
function paraPanel(){
  var log=h("div",{class:"stack"},entries(S.paras,"Demandé : "));
  if(pending==="para")log.append(h("div",{class:"entry"},h("div",{class:"res pending"},"…")));
  var hyp=h("textarea",{id:"hyp",rows:"3",placeholder:"Ex : 1. Paludisme grave  2. Fièvre typhoïde  3. Méningite",
    oninput:function(e){S.hyp=e.target.value;save(KEY,S);}});
  hyp.value=S.hyp||"";
  return h("section",{class:"card"},
    h("h2",null,"Examens complémentaires"),
    h("p",{class:"small muted"},"Note d'abord tes hypothèses, puis demande les examens utiles. Les examens inutiles coûtent des points. Sépare les examens par des virgules."),
    h("div",{class:"field"},h("label",{class:"label",for:"hyp"},"Hypothèses diagnostiques"),hyp),
    log,
    composer("para-in","para","Ex : goutte épaisse, NFS, glycémie, radiographie du thorax","Examens à demander",sendPara),
    navRow("Conclusion"));
}
async function sendPara(){
  var t=draft.para.trim();if(!t||busy)return;
  pending="para";busy=true;render();afterSend();
  await delay(500);
  var r=paraReply(S,t);
  S.paras.push({q:t,a:r.text});S.testIds=uniq((S.testIds||[]).concat(r.ids));
  draft.para="";pending=null;busy=false;save(KEY,S);render();afterSend();
}

/* Étape 4 : conclusion */
function conclPanel(){
  var dx=h("input",{id:"dx",type:"text",placeholder:"Diagnostic principal",value:draft.dx||S.dx||"",oninput:function(e){draft.dx=e.target.value;}});
  var tx=h("textarea",{id:"tx",rows:"6",placeholder:"Médicaments (molécule, dose, voie, durée), mesures associées, surveillance, éducation, suivi",oninput:function(e){draft.tx=e.target.value;}});
  tx.value=draft.tx||S.tx||"";
  var ori=h("select",{id:"ori",onchange:function(e){draft.ori=e.target.value;}},ORIS.map(function(o){return h("option",{value:o,selected:o===draft.ori},o);}));
  return h("section",{class:"card"},
    h("h2",null,"Conclusion"),
    h("p",{class:"small muted"},"Donne ton diagnostic et ta conduite à tenir. L'évaluation compare ton raisonnement au dossier complet."),
    h("div",{class:"field"},h("label",{class:"label",for:"dx"},"Diagnostic retenu"),dx),
    h("div",{class:"field"},h("label",{class:"label",for:"ori"},"Orientation"),ori),
    h("div",{class:"field"},h("label",{class:"label",for:"tx"},"Traitement et conduite à tenir"),tx),
    h("div",{class:"row"},h("button",{class:"btn",type:"button",onclick:finish},"Valider et voir mon évaluation")),
    navRow(null));
}
function finish(){
  if(!draft.dx.trim()||!draft.tx.trim()){err="Renseigne le diagnostic et la conduite à tenir avant de valider.";render();window.scrollTo(0,0);return;}
  S.dx=draft.dx.trim();S.tx=draft.tx.trim();S.ori=draft.ori;err="";
  S.ev=evaluate(S);S.done=true;
  hist.push({t:Date.now(),did:S.did,svc:DB[S.did].svc,dx:DB[S.did].name,total:S.ev.total,ax:S.ev.scores});
  if(hist.length>200)hist=hist.slice(-200);
  save(HKEY,hist);save(KEY,S);
  view="eval";render();window.scrollTo(0,0);
}

/* =====================================================================
   ÉVALUATION
   ===================================================================== */
function listCard(title,arr){
  if(!Array.isArray(arr)||!arr.length)return null;
  return h("section",{class:"card"},h("h3",null,title),h("ul",{class:"list"},arr.map(function(x){return h("li",null,String(x));})));
}
function evalView(){
  var ev=S.ev,d=ev.d,dz=DB[S.did],lv=level(ev.total);
  var root=h("div",{class:"stack"});
  root.append(h("section",{class:"card score "+lv[1]},
    h("div",{class:"big"},h("b",null,String(ev.total)),h("span",null,"/100")),
    h("div",null,h("div",{class:"lvl "+lv[1]},lv[0]),h("p",null,d.verdict))));

  var ax=h("section",{class:"card"},h("h3",null,"Par compétence"));
  AXES.forEach(function(a){
    var s=ev.scores[a[0]];
    ax.append(h("div",{class:"axis"},
      h("div",{class:"head"},h("span",null,a[1]),h("span",null,s+"/10")),
      h("div",{class:"meter"},h("i",{class:s<5?"weak":"",style:{width:(s*10)+"%"}})),
      h("p",{class:"small muted"},d.commentaires[a[0]]||"")));
  });
  root.append(ax);

  root.append(listCard("Points forts",d.points_forts),listCard("À améliorer",d.a_ameliorer),listCard("Questions, examens et éléments oubliés",d.questions_manquantes));

  var dxCard=h("section",{class:"card"},
    h("h3",null,"Diagnostic attendu"),
    h("p",null,h("b",null,dz.name)),
    h("p",{class:"small muted"},"Ta réponse : "+S.dx),
    S.hyp?h("p",{class:"small muted"},"Tes hypothèses : "+S.hyp):null,
    h("p",null,d.explication),
    h("div",{class:"stack"},h("div",{class:"label"},"Différentiels à écarter"),h("div",{class:"chips"},d.differentiels_a_ecarter.map(function(x){return h("span",{class:"chip static"},x);}))));
  root.append(dxCard);

  root.append(h("section",{class:"card"},h("h3",null,"Conduite attendue"),h("p",null,d.traitement_attendu),h("p",{class:"small muted"},"Ta réponse : "+S.tx+" (orientation : "+S.ori+")")));
  root.append(listCard("Pièges classiques",d.pieges));
  root.append(h("section",{class:"card"},h("h3",null,"À réviser"),h("div",{class:"chips"},d.a_reviser.map(function(x){return h("span",{class:"chip static"},x);}))));

  root.append(h("p",{class:"small muted"},"Cas écrits pour l'entraînement. Vérifie toujours les doses et les conduites dans tes protocoles nationaux et tes ouvrages de référence."));
  root.append(h("div",{class:"row"},
    h("button",{class:"btn",type:"button",onclick:function(){S=null;wipe(KEY);go("home");}},"Nouveau cas"),
    h("button",{class:"btn ghost",type:"button",onclick:function(){go("progress");}},"Ma progression")));
  return root;
}

/* =====================================================================
   PROGRESSION
   ===================================================================== */
function progressView(){
  var root=h("div",{class:"stack"});
  root.append(h("h1",null,"Ma progression"));
  if(!hist.length){
    root.append(h("section",{class:"card"},h("p",null,"Aucun cas terminé pour l'instant."),
      h("p",{class:"small muted"},"Termine un cas et ton évaluation apparaîtra ici, avec tes points forts et les compétences à travailler."),
      h("div",{class:"row"},h("button",{class:"btn",type:"button",onclick:function(){go(S&&!S.done?"case":"home");}},"Commencer un cas"))));
    return root;
  }
  var n=hist.length;
  var avg=Math.round(hist.reduce(function(s,x){return s+x.total;},0)/n);
  var last=hist[n-1].total;
  root.append(h("section",{class:"card"},h("div",{class:"kpis"},
    h("div",{class:"kpi"},h("b",null,String(n)),h("span",{class:"small muted"},n>1?"cas terminés":"cas terminé")),
    h("div",{class:"kpi"},h("b",null,String(avg)),h("span",{class:"small muted"},"moyenne /100")),
    h("div",{class:"kpi"},h("b",null,String(last)),h("span",{class:"small muted"},"dernier cas")))));

  var means=AXES.map(function(a){
    var vals=hist.filter(function(x){return x.ax&&typeof x.ax[a[0]]==="number";}).map(function(x){return x.ax[a[0]];});
    return {k:a[0],name:a[1],m:vals.length?vals.reduce(function(s,v){return s+v;},0)/vals.length:0};
  });
  var weakest=means.reduce(function(a,b){return b.m<a.m?b:a;});
  var axCard=h("section",{class:"card"},h("h3",null,"Moyenne par compétence"));
  means.forEach(function(a){
    axCard.append(h("div",{class:"axis"},
      h("div",{class:"head"},h("span",null,a.name),h("span",null,a.m.toFixed(1)+"/10")),
      h("div",{class:"meter"},h("i",{class:a.k===weakest.k?"weak":"",style:{width:(a.m*10)+"%"}}))));
  });
  if(n>=2)axCard.append(h("p",{class:"small muted"},"À travailler en priorité : "+weakest.name+"."));
  root.append(axCard);

  var recent=hist.slice(-10);
  var W=360,H=150,pad=22,bw=(W-pad*2)/recent.length;
  var svgNS="http://www.w3.org/2000/svg";
  var svg=document.createElementNS(svgNS,"svg");
  svg.setAttribute("viewBox","0 0 "+W+" "+H);svg.setAttribute("class","chart");svg.setAttribute("role","img");
  svg.setAttribute("aria-label","Scores des "+recent.length+" derniers cas");
  function add(tag,at,txt){var el=document.createElementNS(svgNS,tag);for(var k in at)el.setAttribute(k,at[k]);if(txt!=null)el.textContent=txt;svg.appendChild(el);}
  var top=18,base=H-22,ch=base-top;
  add("line",{x1:pad,x2:W-pad,y1:base,y2:base});
  add("line",{x1:pad,x2:W-pad,y1:top+ch*0.4,y2:top+ch*0.4,"stroke-dasharray":"3 3"});
  add("text",{x:2,y:top+ch*0.4+3},"60");
  recent.forEach(function(x,i){
    var bh=Math.max(2,ch*x.total/100),bx=pad+i*bw+bw*0.15,w=bw*0.7;
    add("rect",{x:bx,y:base-bh,width:w,height:bh,rx:2});
    add("text",{x:bx+w/2,y:base-bh-4,"text-anchor":"middle",class:"v"},String(x.total));
    add("text",{x:bx+w/2,y:H-8,"text-anchor":"middle"},fmtDate(x.t));
  });
  root.append(h("section",{class:"card"},h("h3",null,"Derniers scores"),svg));

  var hl=h("div",{class:"hist"});
  hist.slice(-8).reverse().forEach(function(x){
    hl.append(h("div",{class:"it"},
      h("div",null,h("div",null,x.dx),h("div",{class:"small muted"},fmtDate(x.t)+" · "+x.svc)),
      h("div",{class:"sc"},x.total+"/100")));
  });
  root.append(h("section",{class:"card"},h("h3",null,"Historique"),hl,
    h("p",{class:"small muted"},"L'historique est gardé dans ce navigateur, sur cet appareil.")));

  root.append(h("div",{class:"row"},
    confirmWipe?h("button",{class:"btn danger",type:"button",onclick:function(){hist=[];wipe(HKEY);confirmWipe=false;render();}},"Confirmer l'effacement"):
      h("button",{class:"btn ghost",type:"button",onclick:function(){confirmWipe=true;render();}},"Effacer l'historique"),
    confirmWipe?h("button",{class:"btn ghost",type:"button",onclick:function(){confirmWipe=false;render();}},"Annuler"):null));
  return root;
}

/* =====================================================================
   RENDU
   ===================================================================== */
window._appRender = function(){ app.replaceChildren(); navCase.setAttribute("aria-current",view!=="progress"?"page":"false"); navProg.setAttribute("aria-current",view==="progress"?"page":"false"); if(err)app.append(h("div",{class:"banner",role:"alert"},err)); if(view==="case"&&S&&!S.done)app.append(caseView()); else if(view==="eval"&&S&&S.ev)app.append(evalView()); else if(view==="progress")app.append(progressView()); else{view="home";app.append(homeView());} }; function render(){
  app.replaceChildren();
  navCase.setAttribute("aria-current",view!=="progress"?"page":"false");
  navProg.setAttribute("aria-current",view==="progress"?"page":"false");
  if(err)app.append(h("div",{class:"banner",role:"alert"},err));
  if(view==="case"&&S&&!S.done)app.append(caseView());
  else if(view==="eval"&&S&&S.ev)app.append(evalView());
  else if(view==="progress")app.append(progressView());
  else{view="home";app.append(homeView());}
}
render();
})();

