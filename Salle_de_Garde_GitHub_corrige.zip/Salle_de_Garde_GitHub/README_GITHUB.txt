SALLE DE GARDE — VERSION CORRIGÉE POUR GITHUB PAGES

CONTENU
- index.html : page principale (basée sur la version ROBUST).
- cases_202.js : bibliothèque de cas cliniques réparée.

CORRECTIONS APPLIQUÉES
1. Réparation de la déclaration JavaScript invalide « D = D., » dans la bibliothèque.
2. Les cas supplémentaires sont ajoutés correctement au tableau D.
3. Le nom de fichier correspond à celui que la page charge : cases_202.js.
4. Vérification de syntaxe JavaScript : réussie pour la bibliothèque et les scripts intégrés de la page.
5. Vérification d'exécution de la bibliothèque : 202 cas chargés, 202 identifiants uniques.

INSTALLATION SUR GITHUB (TÉLÉPHONE OU ORDINATEUR)
1. Ouvre ton dépôt GitHub qui héberge Salle de Garde.
2. Fais une copie de sauvegarde des anciens fichiers avant de les remplacer.
3. Dans la racine du dépôt (pas dans un sous-dossier), ajoute/remplace les fichiers suivants :
   - index.html
   - cases_202.js
   Attention : le nom doit être exactement cases_202.js, sans « .txt ».
4. Appuie sur Commit changes / Valider les modifications.
5. Dans le dépôt, ouvre Settings → Pages.
6. Dans Build and deployment, choisis Deploy from a branch.
7. Choisis la branche utilisée par ton site (souvent main) et le dossier /(root), puis Save.
8. Attends la fin du déploiement et ouvre l'adresse du site GitHub Pages.
9. Sur Android, recharge le site complètement. Si l'ancienne version reste affichée, ouvre le site dans une fenêtre privée ou vide le cache du navigateur.

IMPORTANT
- Ne téléverse pas simultanément plusieurs anciens fichiers HTML comme versions principales. GitHub Pages doit servir le fichier index.html.
- Garde index.html et cases_202.js dans le même dossier à la racine.
- Ne supprime pas les anciens fichiers avant d'avoir une sauvegarde.
- Les tests effectués ici vérifient la syntaxe et le chargement de la bibliothèque. Ils ne remplacent pas un test complet dans le navigateur avec les paramètres Firebase/authentification et les fonctions de l'application.
- Si une page blanche persiste après le déploiement, envoie-moi l'adresse publique GitHub Pages et une capture d'écran ou le message d'erreur : je pourrai diagnostiquer le problème restant.
